﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main(string[] args)
    {
        string text = "Salom, bu yerda email test@example.com bor va boshqa email: hello123@mail.uz. Raqamlar: 123, 456. Salom yana!";

        Console.WriteLine("1. Email has:");
        CheckEmailExists(text);

        Console.WriteLine("\n2. All Emails:");
        FindAllEmails(text);

        Console.WriteLine("\n3. 'Salom words:");
        FindSalomWords(text);

        Console.WriteLine("\n4. All Numbers:");
        FindAllNumbers(text);

        Console.WriteLine("\n5. Change probels to '..': ");
        ReplaceSpaces(text);
    }

    static void CheckEmailExists(string input)
    {
        bool hasEmail = Regex.IsMatch(input, @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}");
        Console.WriteLine("Email has : " + hasEmail);
    }

    static void FindAllEmails(string input)
    {
        var matches = Regex.Matches(input, @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}");
        foreach (Match match in matches)
        {
            Console.WriteLine("Emails: " + match.Value);
        }
    }

    static void FindSalomWords(string input)
    {
        var matches = Regex.Matches(input, @"\bSalom\b", RegexOptions.IgnoreCase);
        foreach (Match match in matches)
        {
            Console.WriteLine("Find: " + match.Value);
        }
    }

    static void FindAllNumbers(string input)
    {
        var matches = Regex.Matches(input, @"\d+");
        foreach (Match match in matches)
        {
            Console.WriteLine("Number: " + match.Value);
        }
    }

    static void ReplaceSpaces(string input)
    {
        string result = Regex.Replace(input, @"\s", "..");
        Console.WriteLine(result);
    }
}

















