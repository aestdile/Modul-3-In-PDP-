using System;
using System.IO;

class Task6
{
    delegate void PrintDelegate(string msg);

    static void PrintToConsole(string msg) => Console.WriteLine("Console: " + msg);

    static void PrintToFile(string msg)
    {
        File.AppendAllText("output.txt", msg + Environment.NewLine);
        Console.WriteLine("File: " + msg);
    }

    static void Main()
    {
        PrintDelegate printer = PrintToConsole;
        printer += PrintToFile;
        printer("Salom, Delegate zanjiri!");
    }
}
