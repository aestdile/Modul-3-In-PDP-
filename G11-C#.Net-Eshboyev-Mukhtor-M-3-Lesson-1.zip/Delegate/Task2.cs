using System;

class Task2
{
    delegate int SumDelegate(int a, int b);
    static int Sum(int a, int b) => a + b;

    static void Main()
    {
        SumDelegate sum = Sum;
        Console.WriteLine("Sum: " + sum(3, 5));
    }
}
