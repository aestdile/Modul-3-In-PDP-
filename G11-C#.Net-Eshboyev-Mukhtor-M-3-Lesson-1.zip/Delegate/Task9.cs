using System;

class Task9
{
    delegate int Operation(int a, int b);
    static int Sum(int a, int b) => a + b;
    static int Multiply(int a, int b) => a * b;

    static void Main()
    {
        Console.Write("Amalni tanlang (+ yoki *): ");
        char op = Console.ReadKey().KeyChar;
        Console.WriteLine();

        Operation operation = op == '+' ? Sum : Multiply;
        Console.WriteLine("Natija: " + operation(4, 5));
    }
}
