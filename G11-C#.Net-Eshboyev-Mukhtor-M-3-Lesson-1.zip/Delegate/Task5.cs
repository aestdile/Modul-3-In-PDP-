using System;

class Task5
{
    static void Main()
    {
        Func<int, int> square = x => x * x;
        Console.WriteLine("3^2 = " + square(3));
        Console.WriteLine("5^2 = " + square(5));
        Console.WriteLine("10^2 = " + square(10));
    }
}
