using System;

class Task4
{
    delegate string ConcatDelegate(string a, string b);
    static string ConcatStrings(string a, string b) => a + b;

    static void Main()
    {
        ConcatDelegate concat = ConcatStrings;
        Console.WriteLine(concat("Salom ", "Dunyo!"));
    }
}
