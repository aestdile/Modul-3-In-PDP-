using System;

class Task8
{
    delegate bool FilterDelegate(int x);
    static bool IsEven(int x) => x % 2 == 0;

    static void PrintFiltered(int[] arr, FilterDelegate filter)
    {
        foreach (var x in arr)
            if (filter(x))
                Console.Write(x + " ");
        Console.WriteLine();
    }

    static void Main()
    {
        int[] numbers = { 1, 2, 3, 4, 5, 6 };
        PrintFiltered(numbers, IsEven);
    }
}
