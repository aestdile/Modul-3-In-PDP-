using System;

class Task3
{
    delegate double CircleAreaDelegate(double r);
    static double CalculateArea(double r) => Math.PI * r * r;

    static void Main()
    {
        CircleAreaDelegate area = CalculateArea;
        Console.WriteLine("Doira yuzasi: " + area(7));
    }
}
