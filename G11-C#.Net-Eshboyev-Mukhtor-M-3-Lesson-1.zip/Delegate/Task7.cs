using System;

class Task7
{
    static void CountToN(int n, Action<int> print)
    {
        for (int i = 1; i <= n; i++)
            print(i);
    }

    static void Main()
    {
        CountToN(5, Console.WriteLine);
    }
}
