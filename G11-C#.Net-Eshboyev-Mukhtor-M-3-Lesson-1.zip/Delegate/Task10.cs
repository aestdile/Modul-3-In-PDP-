using System;

class Task10
{
    static void Hello() => Console.WriteLine("Hello");
    static void Bye() => Console.WriteLine("Bye");

    static void Main()
    {
        Action chain = Hello;
        chain += Bye;
        chain.Invoke();
    }
}
