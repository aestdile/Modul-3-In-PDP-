using System;

class Task1
{
    delegate void GreetDelegate(string name);
    static void SayHello(string name) => Console.WriteLine($"Salom, {name}!");

    static void Main()
    {
        GreetDelegate greet = SayHello;
        greet("Ali");
    }
}
